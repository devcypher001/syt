<?php
$config['callback_url']         =   'http://sellyourtime.in/facebook?fbTrue=true'; //   /?fbTrue=true allow you to code process section.

//Facebook configuration
$config['App_ID']      =   '1535443476729064';
$config['App_Secret']  =   'e9b86de4658d3995bea5aa82a2320692'; 

?>