<?php
mysql_connect("localhost","sellyour_asdfg","helloworld001");
mysql_select_db("sellyour_syt001");
?>