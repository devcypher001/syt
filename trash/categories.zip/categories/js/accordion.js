$(function(){
	$("#itd").click(function(){
		$("#its").toggle();
	});
	
	$("#mkd1").click(function(){
		
		$("#mks1").toggle();
	});
	
	$("#mkd2").click(function(){
		//$("#its").slideUp();
		$("#mks2").toggle();
	});
	
	$("#mkd3").click(function(){
		//$("#its").slideUp();
		$("#mks3").toggle();
	});
	
	$("#mkd4").click(function(){
		//$("#its").slideUp();
		$("#mks4").toggle();
	});
	
	$("#mkd5").click(function(){
		//$("#its").slideUp();
		$("#mks5").toggle();
	});
	
	$("#mkd6").click(function(){
		//$("#its").slideUp();
		$("#mks6").toggle();
	});
});