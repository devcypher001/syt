<?php
/**
 * DB configuration variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "sellyour_api");
define("DB_PASSWORD", "helloworld");
define("DB_DATABASE", "sellyour_demo_api");
?>