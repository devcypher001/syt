<?php
 $response = file_get_contents('http://bulkpush.mytoday.com/BulkSms/SingleMsgApi?feedid=349679&username=9650222676&password=gdjmp&To=919899873343&Text=Aur%20mittal%20kya%20haal%20hai');
 
 print_r($response);
?>