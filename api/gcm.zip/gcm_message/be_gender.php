<?php
include  '../gcm_message.php';
include '../../connect.php';

$message = $_POST['message'];
$gender = $_POST['gender'];
$http_link = $_POST['http_link'];

$selected_user=array();
$regID = mysql_query("SELECT * FROM `syt_registration` where (`regID` <> '' AND `gender`='$gender')");
//$fetch_regID = mysql_fetch_array($regID);
while($row = mysql_fetch_assoc($regID))
{
	array_push($selected_user, 'APA91bFu-BoKlpZeePDV5mAy3-Ui_We2gWZkqxD0dNaWMB6AfzNkxteU4M4tHz9fnWKJwWkcxpDlURLCp73yHy83XcJ-3FLbSlFuJOpqfW3kop5JoGkdZFKIzlxiVU-KxaNmWmdv9L-a');
}

$notification_type = "admin_message";
$greetMsg = "$message";
$respJson = '{"notification_type":"'.$notification_type.'","greetMsg":"'.$greetMsg.'","http_link":"'.$http_link.'"}';
	
$message = array("m" => $respJson); 
	
$pushsts = sendPushNotificationToGCM($selected_user, $message);

echo 1;
?>